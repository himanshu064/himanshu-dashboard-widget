const eslint = require("./node_modules/@telesero/frontend-common/build-tools/eslint.js");

module.exports = eslint;
