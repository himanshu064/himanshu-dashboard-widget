## [1.0.95](https://github.com/Telesero/widget-base/compare/1.0.94...1.0.95) (2025-02-24)



## [1.0.94](https://github.com/Telesero/widget-base/compare/1.0.93...1.0.94) (2025-02-18)



## [1.0.93](https://github.com/Telesero/widget-base/compare/1.0.92...1.0.93) (2024-12-09)



## [1.0.92](https://github.com/Telesero/widget-base/compare/1.0.91...1.0.92) (2024-09-13)



## [1.0.91](https://github.com/Telesero/widget-base/compare/1.0.90...1.0.91) (2024-09-09)



