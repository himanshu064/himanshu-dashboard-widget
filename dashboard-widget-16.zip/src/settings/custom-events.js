const CustomEvents = {
  OpenHelpbot: "@ev/open_helpbot",
  // Raise event
  RefreshQueues: "@ev/refresh_queues",

  // Subscribe event
  IncomingRefreshQueues: "@ev/refresh_queues_to_dashboard"
};

export default CustomEvents;
