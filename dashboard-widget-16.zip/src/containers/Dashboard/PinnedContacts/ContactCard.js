import React from "react";
import { useHistory } from "react-router-dom";
import {
  Box,
  Typography,
  Avatar,
  Card,
  Chip,
  Tooltip,
  useTheme
} from "@material-ui/core";
import { getModuleById, ModuleNames } from "../../../utils/modules";
import { useAdvertisedPages } from "../../../store/advertised-pages";
import ControlledDialog from "../../../components/Control/ControlledDialog";
import { useContactCardStyles } from "./styles";
import { getApiUrl } from "../../../constants";

const PinIcon = ({ className, onClick }) => {
  const theme = useTheme();
  return (
    <svg
      data-name="Layer 1"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 122.48 122.88"
      height={18}
      width={18}
      className={className}
      onClick={onClick}
      fill={theme.palette.primary.main}
    >
      <defs></defs>
      <path
        class="cls-1"
        d="M121.21,36.53,85.92,1.23c-3-3-7.77.1-9.2,2.74-.24.45.19.86-.2,3.92A46.27,46.27,0,0,1,73.8,19.21L58.11,34.91c-6.27,6.26-15.23,3.48-22.87-.32-1.62-.8-3.69-2.57-5.48-.78l-6.64,6.64a2.49,2.49,0,0,0,0,3.53L78.9,99.76a2.5,2.5,0,0,0,3.53,0l6.64-6.64c1.77-1.77-.49-4.06-1.41-6-3.4-7-6.45-16.41-.78-22.08l16.39-16.39a84.14,84.14,0,0,1,11.35-2.57c3.09-.49,3.47-.11,3.91-.4,2.71-1.74,5.7-6.15,2.68-9.17Z"
      />
      <polygon
        class="cls-2"
        points="53.48 82.11 40.77 69.4 0 120.96 1.92 122.88 53.48 82.11 53.48 82.11"
      />
    </svg>
  );
};

const contactPathPrefix = {
  customer: "customers",
  lead: "leads",
  Customer: "customers",
  Lead: "leads"
};

const ContactCard = ({ contact, unpinLoading, handleUnpin }) => {
  const advertisedPages = useAdvertisedPages();
  const classes = useContactCardStyles();
  const history = useHistory();

  const [openConfirm, setOpenConfirm] = React.useState(false);

  const handleViewProfile = () => {
    const crmModule = getModuleById(advertisedPages, ModuleNames.Crm);
    const url = `${crmModule.url}${crmModule.url.endsWith("/") ? "" : "/"}${
      contactPathPrefix[contact?.contact?.class_label]
    }/${contact?.contact?.id}`;

    const isInternalUrl = url.startsWith(getApiUrl());

    if (isInternalUrl) {
      history.push(
        `/${contactPathPrefix[contact?.contact?.class_label]}/${
          contact?.contact?.id
        }`
      );
      return;
    }

    window.open(url, "_blank");
  };

  return (
    <>
      <Card elevation={0} className={classes.container}>
        <Box className={classes.avatarContainer}>
          <Avatar />
          <Tooltip title={`Unpin ${contact?.contact?.class_label}`} arrow>
            <span>
              <PinIcon
                className={classes.pinIcon}
                onClick={(event) => {
                  event.stopPropagation();
                  setOpenConfirm(true);
                }}
              />
            </span>
          </Tooltip>
        </Box>
        <Box className={classes.contactDetails}>
          <Typography className={classes.nameContainer}>
            <span onClick={handleViewProfile} className={classes.contactName}>
              {contact?.contact?.first_name || ""}{" "}
              {contact?.contact?.last_name || ""}
            </span>
            <Chip
              size="small"
              label={contact?.contact?.class_label}
              variant="outlined"
            />
          </Typography>
          <Typography variant="subtitle2">
            <a
              href={`mailto:${contact?.contact?.email}`}
              className={classes.links}
            >
              {contact?.contact?.email}
            </a>
          </Typography>
          <Typography variant="subtitle2">
            <a
              href={`tel:${contact?.contact?.phone}`}
              className={classes.links}
            >
              {contact?.contact?.phone}
            </a>
          </Typography>
        </Box>
      </Card>

      {/* Unpin Confirm */}
      <ControlledDialog
        loading={unpinLoading}
        open={openConfirm}
        title={`Unpin ${contact?.contact?.class_label || ""} - ${
          contact?.contact?.first_name
        }`}
        content={`Are you sure want to unpin this ${contact?.contact?.class_label}? This action cannot be undone.`}
        closeFn={() => setOpenConfirm(false)}
        confirmFn={() => {
          return handleUnpin(contact?.id);
        }}
      />
    </>
  );
};

export default ContactCard;
