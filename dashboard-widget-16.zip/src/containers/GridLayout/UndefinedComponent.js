const UndefinedComponent = () => {
  return "Undefined Component";
};

export default UndefinedComponent;
