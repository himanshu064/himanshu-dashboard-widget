let advertisedPages = [];

export const useAdvertisedPages = () => advertisedPages;
export const setAdvertisedPages = (pages) => {
  advertisedPages = pages;
};
