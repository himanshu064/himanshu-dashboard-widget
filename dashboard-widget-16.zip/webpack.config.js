// webpack.config.js
const neutrino = require("neutrino");

module.exports = neutrino().webpack();
