// This file has no effect this is for auto completion in PhpStorm/WebStorm
// eslint-disable-next-line no-undef
System.config({
  paths: {
    "@telesero/assets/*": "node_modules/@telesero/frontend-common/assets/*"
  }
});
