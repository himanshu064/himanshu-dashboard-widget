# widget-base

### Export
```yarn babel src/widgetLoader/index.js --out-file build/widget-base.js```



